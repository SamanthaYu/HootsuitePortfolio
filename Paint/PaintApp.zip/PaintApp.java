/*****************************************************************************
*   Lab13: The Paint Program
*   Name: Samantha Yu
*   Submitted to AP Computer Science 12: January 27, 2015
*   Last modified: April 4, 2015
*   Teacher: Christopher Slowley
******************************************************************************/

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Frame;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class PaintApp extends Frame implements WindowListener, MouseListener, MouseMotionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5650761267721782655L;
	
	// Used when creating the frame of the paint program
	private int appWidth, appHeight, canvasHeight;
	private Menu menuBar;
	private Tools toolbar;
	
	private int menuHeight;
	private Rectangle canvasRect;	// Canvas is not visible and does not include menu bar
	
	private boolean firstPaint, menuChange, continuePaint;	// Used as "switches" during program execution
	private int oldX, oldY, newX, newY;		// Used on mouse events

	private Graphics2D g2Frame;
		// The Graphics2D class provides "more sophisticated control over geometry, coordinate transformations, color management, and text layout"
		// (see "http://docs.oracle.com/javase/7/docs/api/java/awt/Graphics2D.html") than its superclass, the Graphics class,
		// Such as being able to paint lines that have different edges
	private Layers layersArray;
	
	public static void main(String args[]) {	// The main method handles the application's framework (such as event listeners) and makes the window visible
		PaintApp paintProgram = new PaintApp();
		paintProgram.addWindowListener(paintProgram);
		paintProgram.addMouseListener(paintProgram);
		paintProgram.addMouseMotionListener(paintProgram);
		
		paintProgram.appWidth = 761;
		paintProgram.appHeight = 380;
		paintProgram.setSize(paintProgram.appWidth, paintProgram.appHeight);
		
		paintProgram.setVisible(true);
		paintProgram.createApp();
	}
	
	public void createApp() {	// Menu bar, canvas, layers array, and toolbar are created
		menuHeight = 75;
		createCanvas();
		layersArray = new Layers(this);
		// The menu bar's selection boxes are created but not the buttons that you can see; i.e. buttons are invisible
		menuBar = new Menu(this, layersArray);
		toolbar = new Tools(this, menuBar, layersArray);
		firstPaint = true;
	}
	
	public void paint(Graphics g) {		// Called after paintProgram became visible and whenever the graphical output needs to be updated or repainted
		g2Frame = (Graphics2D) g;		// The abstract Graphics2D class extends the abstract Graphics class

		if (firstPaint) {	
			menuBar.createMenu();		// Menu items are drawn onto the menu off-screen image
			g2Frame.drawImage(menuBar.menuImage, 0, 0, this);	// Off-screen image is drawn onto the application; menu becomes visible
			
			firstPaint = false;
			continuePaint = true;
		}
		else {
			if (continuePaint) {	// If a user's mouse did not click inside the menu, the mouse paints with the user's selected tool, size, and color
				toolbar.useTool(menuBar.getNumTool(), oldX, oldY, newX, newY);
			}
			else {	// If a menu item is selected, then the area underneath the menu is not painted
				continuePaint = true;	// When the user selects a large size for their tool, then the canvas will not be accidentally painted.
			}
			
			paintLayers(g2Frame);
			
			if (menuChange) {	// If the user has selected a menu item, the menu bar is updated and redrawn
				menuBar.changeToolMenu();
				menuChange = false;
			}
			
			g2Frame.drawImage(menuBar.menuImage, 0, 0, this); // Prevents the menu bar from disappearing when the application has gone inactive or been resized
		}
	}
	
	public void paintLayers(Graphics2D g2Frame) {	// When a layer is created or deleted, or the user decides to switch to a different layer
		if (layersArray.deleteLayer) {	// A layer is deleted (can be any layer, not just the last layer in imageArray, that is not the only layer lef)
			g2Frame.drawImage(layersArray.getImageArray().get(layersArray.getcLayerNum()), 0, getMenuHeight(), this);		// Draws the blank deleted layer
				// Otherwise, the deleted layer will remain and is not erased on screen
			
			for (int k = 0; k < layersArray.getImageArray().size(); k++) {			// Then draws the rest of the layers in ascending order
				if (k!=layersArray.getcLayerNum()) {
					g2Frame.drawImage(layersArray.getImageArray().get(k), 0, getMenuHeight(), this);
				}
			}
			
			layersArray.deleteLayer = false;
			layersArray.getImageArray().remove(layersArray.getcLayerNum());			// Removes the blank deleted layer from imageArray
			
			if (layersArray.getcLayerNum() == layersArray.getImageArray().size())	// If the deleted layer was the last layer, then decrease cLayerNum
				layersArray.setcLayerNum(layersArray.getcLayerNum() - 1);			// If not, then cLayerNum is not decreased
				// eg If the third layer is deleted, then the next layer which used to be the fourth layer is now the third layer
			
			g2Frame.drawImage(layersArray.getImageArray().get(layersArray.getcLayerNum()), 0, getMenuHeight(), this);	// The current layer is drawn last for visibility
		}
		else {	// If you are not deleting a layer, update only the current layer's graphics.
				// If you constantly redrawing the other layers, then those other layers will flicker in the background
			g2Frame.drawImage(layersArray.getImageArray().get(layersArray.getcLayerNum()), 0, getMenuHeight(), this);
		}
		
		if (layersArray.changeLayer) {	// If a layer is created or deleted, or the user switches to the previous or next layer
			menuBar.changeLayerMenu();	// Layer status is updated
			layersArray.changeLayer = false;
		}
	}
	
	public void windowClosing(WindowEvent e) {
	    dispose();
	    System.exit(0);	// Normal exit of program
	}
	
	// These window events are required to be implemented, because this class implements the WindowListener
	// However, this paint program does not need these window events so these methods are left blank
	public void windowOpened(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowActivated(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}
	
	private void createCanvas() {	// Creates the canvas that the user can draw on; user cannot draw on menu
		canvasHeight = appHeight - getMenuHeight();
		canvasRect = new Rectangle(0,getMenuHeight(),appWidth, canvasHeight);
	}
	
	public int getAppWidth() {		// Returns the private appWidth attribute
		return appWidth;
	}
	
	public int getCanvasHeight() {	// Returns the private canvasHeight attribute
		return canvasHeight;
	}
	
	public int getMenuHeight() {	// Returns the private menuHeight attribute
		return menuHeight;
	}
	
	// These mouse events are required to be implemented, because this class implements the MouseListener and MouseMotionListener
	// However, this paint program does not need these mouse events so these methods are left blank
	public void mouseClicked(MouseEvent e) {}	// When the mouse button is pressed down then released
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseMoved(MouseEvent e) {}		// When the mouse is moving but none of the buttons are held down
	
	public void mousePressed(MouseEvent e) {	// When any of the mouse buttons are pressed down
		menuBar.select(e.getX(), e.getY());
		newX = e.getX();
		newY = e.getY();
		oldX = e.getX();  
		oldY = e.getY();
		
		if (menuBar.menuRect.contains(e.getX(),e.getY())) {
			continuePaint = false;	// After the user selects a menu item, continuePaint will prevent the area under the menu from getting painted.
			menuChange = true;
			repaint();
		}
		
		if (canvasRect.contains(e.getX(), e.getY())) {	// The application repaints if the user clicks inside the canvas
			repaint();
		}
	}
	
	public void mouseDragged(MouseEvent e) {	// When any of the mouse buttons are held down while the mouse is dragged
		oldX = newX;
		oldY = newY;
	   	newX = e.getX();
	   	newY = e.getY();

		if (canvasRect.contains(e.getX(), e.getY())) {	// The application repaints only if the user drags the mouse inside the canvas
			repaint();
		}
	}
	
	public void mouseReleased(MouseEvent e) {		// When any of the mouse buttons are lifted up
		newX = e.getX();
		newY = e.getY();

		if (canvasRect.contains(e.getX(), e.getY())) {	// The application repaints only if the user lifts the mouse inside the canvas
			repaint();
		}
	}

	public void update(Graphics g) {
		// When repaint() is called, the update() then calls paint()
		// Since "default implementation of update() clears the Component's background before calling paint()", 
		// (see http://journals.ecs.soton.ac.uk/java/tutorial/ui/drawing/update.html)
		// I removed the background layers from flickering by drawing the layers here
		for (int k = 0; k < layersArray.getImageArray().size(); k++) {
			g2Frame.drawImage(layersArray.getImageArray().get(k), 0, getMenuHeight(), this);
		}
		paint(g);
	}
}