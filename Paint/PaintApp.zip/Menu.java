/*****************************************************************************
*   Lab13: The Paint Program: Menu class
*   Name: Samantha Yu
*   Submitted to AP Computer Science 12: January 27, 2015
*   Last modified: April 4, 2015
*   Teacher: Christopher Slowley
******************************************************************************/

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import javax.swing.JColorChooser;
import javax.swing.JOptionPane;
import javax.swing.colorchooser.AbstractColorChooserPanel;

public class Menu {
	// Menu buttons are not physically seen, but are the "click-able" items
	Rectangle menuRect, colorRect, sizeRect;
	Rectangle pencilRect, brushRect, sprayRect;
	Rectangle newRect, prevRect, nextRect, delRect;
	
	// Menu appearance
	Color menuColor, paintColor, toolColor, sizeColor, fontColor, layerBtnColor, selectColor;
	Font btnFont;
	private int numTool, strokeSize;
	
	String stringStroke;		// Used when getting the color from dialog boxes
	
	BufferedImage menuImage;	// To prevent the menu bar being erased when the window is no longer active, menuImage will store the current image
	Graphics2D g2Menu;			// g2Menu will paint graphics onto that image when necessary
	
	PaintApp paintLab;	// A PaintApp object has only one instance and allows this class to access its non-static methods and attributes
		// I did not make PaintApp's attributes static, because those attributes refer to the one and same object, the paint program
		// I did not want to place the Menu's methods into PaintApp, because those methods belong in its own separate category
		// So, this Menu class must be able to access the dimensions of PaintApp such as the get methods like getAppWidth()
	Layers layersArray;
	
	public Menu(PaintApp pLab, Layers lArray) {	// When the menu object is constructed, the invisible but "click-able" buttons are also constructed
		paintLab = pLab;		// Initializes paintLab to the actual PaintApp, and layersArray to the actual layers array
		layersArray = lArray;	// So that Menu class' methods can access the non-static fields and methods, such as imageArray
		
		selectColor = new Color(0,0,0);
		fontColor = new Color(0,0,0);
		btnFont = new Font("Georgia",Font.BOLD,17);
		numTool =  1;
		strokeSize = 15;
		
		colorRect = new Rectangle(13, 35, 35, 35);		// Color button (invisible but "click-able")
	     
		pencilRect = new Rectangle(53, 35, 80, 35);		// Tool buttons (invisible but "click-able")
		brushRect = new Rectangle(138, 35, 80, 35);
		sprayRect = new Rectangle(223, 35, 80, 35);
		
		sizeRect = new Rectangle(308, 35, 60, 35);		// Size buttons (invisible but "click-able")
		
		newRect = new Rectangle(373, 35, 70, 35);		// Layer buttons (invisible but "click-able")
		prevRect = new Rectangle(448, 35, 70, 35);
		nextRect = new Rectangle(523, 35, 70, 35);
		delRect = new Rectangle(598, 35, 70, 35);
	    
	    menuRect = new Rectangle(8,30,paintLab.getAppWidth(), paintLab.getMenuHeight());
    }
	
	public void createMenu() {	// Creates the physical appearance of the menu
		menuImage = new BufferedImage(paintLab.getAppWidth(),paintLab.getMenuHeight(),BufferedImage.TYPE_INT_ARGB);
		g2Menu = (Graphics2D) menuImage.getGraphics();
    	
		makeBackgroundMenu();
		makeColorButton();
		makeSizeButton();
		makeToolButtons();
		makeLayerButtons();
	}
	
	private void makeBackgroundMenu() {		// Makes background menu
		menuColor = new Color(71,119,166);
		g2Menu.setColor(menuColor);  
		g2Menu.fillRect(0,0,paintLab.getAppWidth(), paintLab.getMenuHeight()); 
	}
	
	private void makeColorButton() {		// Makes visible color buttons
		paintColor = new Color(121,219,209);
		g2Menu.setColor(paintColor);
		g2Menu.fillRect(13, 35, 35, 35);
    	
		g2Menu.setStroke(new BasicStroke(2, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_ROUND));
		g2Menu.setColor(selectColor);
		g2Menu.drawRect(13, 35, 35, 35);	// Draws border
	}
	
	private void makeToolButtons() {		// Makes visible tool buttons
		toolColor = new Color(240,236,189);
		g2Menu.setColor(toolColor);
		
		g2Menu.fillRoundRect(53, 35, 80, 35, 20, 20);		// 1st Tool Button: Pencil
		g2Menu.fillRoundRect(138, 35, 80, 35, 20, 20);		// 2nd Tool Button: Elastic
		g2Menu.fillRoundRect(223, 35, 80, 35, 20, 20);		// 3rd Tool Button: Paint Bucket
		
		g2Menu.setColor(fontColor);
		g2Menu.setFont(btnFont);
		
		g2Menu.drawString("PENCIL", 58, 58);				// Tool button labels
		g2Menu.drawString("BRUSH", 146, 58);
		g2Menu.drawString("SPRAY", 231, 58);
		
		g2Menu.setStroke(new BasicStroke(2, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_ROUND));
		g2Menu.setColor(selectColor);
		g2Menu.drawRoundRect(53, 35, 80, 35, 20, 20);		// Draws border around first selected tool which is the pencil tool
		
		g2Menu.setColor(menuColor);
		g2Menu.drawRoundRect(138, 35, 80, 35, 20, 20);		// Draws "invisible" border (same color as the menu) on the other two tools
		g2Menu.drawRoundRect(223, 35, 80, 35, 20, 20);	
	}

	private void makeSizeButton() {		// Makes visible size buttons
		sizeColor = new Color(253, 191, 125);
    	
		g2Menu.setColor(sizeColor);
		g2Menu.fillRoundRect(308, 35, 60, 35, 20, 20);
		
		g2Menu.setStroke(new BasicStroke(2, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_ROUND));
		g2Menu.setColor(selectColor);
		g2Menu.drawRoundRect(308, 35, 60, 35, 20, 20);		// Draws border
		
		g2Menu.setColor(fontColor);
		g2Menu.setFont(btnFont);
		
		g2Menu.drawString(strokeSize + " px", 314, 56);
	}
	
	private void makeLayerButtons() {	// Makes visible layer buttons
		layerBtnColor = new Color(119,237,156);
		g2Menu.setColor(layerBtnColor);
		
		g2Menu.fillRoundRect(373, 35, 70, 35, 20, 20);		// Layer Button: New Layer
		g2Menu.fillRoundRect(448, 35, 70, 35, 20, 20);		// Layer Button: Previous Layer
		g2Menu.fillRoundRect(523, 35, 70, 35, 20, 20);		// Layer Button: Next Layer
		g2Menu.fillRoundRect(598, 35, 70, 35, 20, 20);		// Layer Button: Delete Layer
		
		g2Menu.fillRoundRect(673, 35, 75, 35, 20, 20);		// Layer Button: Number of current layer
		
		g2Menu.setColor(fontColor);
		g2Menu.setFont(btnFont);
		
		g2Menu.drawString("NEW", 383, 58);					// Layer button labels
		g2Menu.drawString("PREV.", 457, 58);
		g2Menu.drawString("NEXT", 533, 58);
		g2Menu.drawString("DEL.", 613, 58);
		
		g2Menu.setFont(new Font("Georgia",Font.PLAIN,19));
		g2Menu.drawString("1 of 1", 683, 56);				// Initial layer status (when the paint program begins)
	}
	
	public void select(int x, int y) {		// Selects menu items
		if (colorRect.contains(x, y)) {		// If mouse clicks on the color button
			selectColor();
		}
					    
		if (pencilRect.contains(x, y)) {	// If mouse selects a tool
			numTool = 1;
		}
		else if (brushRect.contains(x, y)) {
			numTool = 2;
		}
		else if (sprayRect.contains(x, y)) {
			numTool = 3;
		}
		
		if (sizeRect.contains(x, y)) {		// If mouse clicks on the size button
			selectSize();
		}
		
		if (newRect.contains(x, y)) {		// If mouse clicks on a layer button
			layersArray.newLayer();
		}
		else if (prevRect.contains(x, y)) {
			layersArray.previousLayer();
		}
		else if (nextRect.contains(x, y)) {
			layersArray.nextLayer();
		}
		else if (delRect.contains(x, y)) {
			layersArray.deleteLayer();
		}
	}
	
	private void selectColor() {	// When the user selects on the color button
		JColorChooser chooser = new JColorChooser();		// Color panel
		AbstractColorChooserPanel[] panels = chooser.getChooserPanels();
		 
		for (AbstractColorChooserPanel accp : panels) {		// Only the RGB tab will show
			if (accp.getDisplayName().equals("RGB")) {
            	JOptionPane.showMessageDialog(null, accp);
			}
		}
		
		paintLab.repaint();	// Repaints the window in case some of the graphics disappeared due to the color chooser popping up
		Color pColor = chooser.getColor();
		
		// Since transparent lines are compounded on top of each other when draw in succession causing the transparent lines to appear opaque
		// I converted the RGBA values into RGB.
		// Now, the color of the menu's color button matches the color drawn on the canvas
		int r, g, b;
		r = pColor.getRed() * pColor.getAlpha() + pColor.getRed() * (255 - pColor.getAlpha());
		g = pColor.getGreen() * pColor.getAlpha() + pColor.getGreen() * (255 - pColor.getAlpha());
		b = pColor.getBlue() * pColor.getAlpha() + pColor.getBlue() * (255 - pColor.getAlpha());
		paintColor = new Color(r / 255, g / 255, b / 255);
		
		changeColorMenu();
	}
	
	private void selectSize() {		// When the user selects on the size button
		do {
			stringStroke = JOptionPane.showInputDialog("How many pixels wide should your paint tools be?");

			if (stringStroke == null) {	// If the user exits the dialog box
				JOptionPane.showMessageDialog(null,"Since you did not provide a value for the width of the paint tool, the width is set to 15 px.");
				strokeSize = 15;
			}
			else {
				strokeSize = Integer.parseInt(stringStroke);
				
				if (strokeSize < 0)		// If the user enters a negative value
					JOptionPane.showMessageDialog(null,"You cannot have a tool with a width less than 0. Please try again with a higher value.");
				else if (strokeSize > paintLab.getCanvasHeight())	// If the user enters an extremely large value
					JOptionPane.showMessageDialog(null,"Using a tool with a width greater than the canvas height (" + paintLab.getCanvasHeight() + " px) is unnecesarily large. Please try again with a lower value.");
			}
		} while ((strokeSize < 0) || (strokeSize > paintLab.getCanvasHeight()));	// Loop will continue until the user provides a positive number smaller than the canvas height
		changeSizeMenu();
	}
	
	private void changeColorMenu() {	// Changes the appearance of the color button after it is clicked
		g2Menu.setColor(Color.white);	// Erases previous button
		g2Menu.fillRect(13, 35, 35, 35);
		
		g2Menu.setColor(paintColor);	// Paints button with new color
		g2Menu.fillRect(13, 35, 35, 35);
    	
		g2Menu.setStroke(new BasicStroke(2, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_ROUND));
		g2Menu.setColor(selectColor);	// Redraws border
		g2Menu.drawRect(13, 35, 35, 35);
	}
	
	public void changeToolMenu() {		// Changes the appearance of the tool button after it is clicked
		g2Menu.setStroke(new BasicStroke(2, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_ROUND));
		g2Menu.setColor(selectColor);
		
		if (numTool == 1)	// Draws border around selected tool box
			g2Menu.drawRoundRect(53, 35, 80, 35, 20, 20);
		else if (numTool == 2)
			g2Menu.drawRoundRect(138, 35, 80, 35, 20, 20);
		else if (numTool == 3)
			g2Menu.drawRoundRect(223, 35, 80, 35, 20, 20);
		
		g2Menu.setColor(menuColor);
		
		// "If" statements instead of "else if", because multiple boxes are not selected at a time
		if (numTool != 1)		// Erases border around previously selected tool box by drawing that same rectangle with the menu color
			g2Menu.drawRoundRect(53, 35, 80, 35, 20, 20);
		if (numTool != 2)
			g2Menu.drawRoundRect(138, 35, 80, 35, 20, 20);
		if (numTool != 3)
			g2Menu.drawRoundRect(223, 35, 80, 35, 20, 20);
	}

	private void changeSizeMenu() {		// Changes the appearance of the size button after it is clicked
		g2Menu.setColor(sizeColor);
		g2Menu.fillRoundRect(308, 35, 60, 35, 20, 20);	// Erases previous size by drawing button again
		
		g2Menu.setStroke(new BasicStroke(2, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_ROUND));
		g2Menu.setColor(selectColor);
		g2Menu.drawRoundRect(308, 35, 60, 35, 20, 20);	// Draws border
		
		g2Menu.setFont(btnFont);
		g2Menu.setColor(fontColor);
		
		// Depending on the number of digits of the size status, the status is printed with a certain size and location
		if (strokeSize <= 99) {
			g2Menu.drawString(strokeSize + " px", 314, 56);
		}
		else {
			g2Menu.setFont(new Font("Georgia",Font.BOLD,14));
			g2Menu.drawString(strokeSize + " px", 312, 56);
		}
	}
	
	public void changeLayerMenu() {		// Changes the appearance of the layers' status after the user has created or deleted a layer, or moved to a different layer
		g2Menu.setColor(layerBtnColor);
		g2Menu.fillRoundRect(673, 35, 75, 35, 20, 20);	// Redraw the layer status rectangle to cover the previous status
		g2Menu.setColor(fontColor);
		
		// Depending on the number of digits in the layer status, the status is printed with a certain size and location
		if ((layersArray.getcLayerNum() < 9) && (layersArray.getImageArray().size() < 10)) {
			g2Menu.setFont(new Font("Georgia",Font.PLAIN,19));
			g2Menu.drawString(String.valueOf(layersArray.getcLayerNum() + 1) + " of " + String.valueOf(layersArray.getImageArray().size()), 683, 56);
		}
		else {
			g2Menu.setFont(new Font("Georgia",Font.PLAIN,17));
			g2Menu.drawString(String.valueOf(layersArray.getcLayerNum() + 1) + " of " + String.valueOf(layersArray.getImageArray().size()), 683, 56);
		}
	}
	
	public int getNumTool() {		// Returns private numTool attribute
		return numTool;
	}
	
	public int getStrokeSize() {	// Returns private numStrokeSize attribute
		return strokeSize;
	}
}