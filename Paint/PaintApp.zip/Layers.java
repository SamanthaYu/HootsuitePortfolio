/*****************************************************************************
*   Lab13: The Paint Program: Layers class
*   Name: Samantha Yu
*   Submitted to AP Computer Science 12: January 27, 2015
*   Last modified: April 4, 2015
*   Teacher: Christopher Slowley
******************************************************************************/

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Layers {
	PaintApp paintLab;	// A PaintApp object has only one instance and allows this class to access its non-static methods and attributes
		// I did not make PaintApp's attributes static, because those attributes refer to the one and same object, the paint program
		// I did not want to place the Menu's methods into PaintApp, because those methods belong in its own separate category
		// So, this Layers class must be able to access and change the graphical output of PaintApp such as the layer methods like repaint()
	
	private ArrayList<BufferedImage> imageArray;	// Stores buffered images of each layer
		// I decided to use the BufferedImage class instead of its superclass, the Image class, due to its ability to include transparency
	private int cLayerNum;	// The index, cLayerNum, of imageArray allows access to the current layer and makes a graphical context for that layer
	
	public boolean deleteLayer, changeLayer;
	
	public Layers(PaintApp pLab) { 	// Creates an ArrayList of BufferedImages to contain the layers and creates an initial layer
		paintLab = pLab;
		imageArray = new ArrayList<BufferedImage>();
		
		BufferedImage bImage = new BufferedImage(paintLab.getAppWidth(), paintLab.getCanvasHeight(), BufferedImage.TYPE_INT_ARGB);
		imageArray.add(bImage);		// Adds the first layer
		cLayerNum = 0;
	}
	
	public void newLayer() {		// Creates a new layer after the current layer
		BufferedImage bImage = new BufferedImage(paintLab.getAppWidth(), paintLab.getCanvasHeight(), BufferedImage.TYPE_INT_ARGB);
		cLayerNum++;
		imageArray.add(cLayerNum,bImage);	// Adds that layer after the current layer
		deleteLayer = false;
		changeLayer = true;
		paintLab.repaint();
	}
	
	public void previousLayer() {	// User switches to the previous layer
		if (cLayerNum > 0) {		// If the previous layer's index exists in imageArray
			cLayerNum--;
			changeLayer = true;
		}
		else {	// Prevents the user from accessing a layer that does not exist and getting an index out of bounds error
			JOptionPane.showMessageDialog(null, "Sorry, but you cannot go to a layer that does not exist yet.");
		}
		paintLab.repaint();	// The graphical output is repainted, because when the notification pops up it erases some of the graphics
			// Also, this allows for the previous layer's graphics to now be at the top and fully visible
	}
	
	public void nextLayer() {	// User switches to the next layer
		if (cLayerNum < imageArray.size() - 1) {	// If the next layer's index exists in imageArray
			cLayerNum++;
			changeLayer = true;
		}
		else {
			JOptionPane.showMessageDialog(null, "Sorry, but you cannot go to a layer that does not exist yet.");
		}
		paintLab.repaint();	// The graphical output is repainted, because when the notification pops up it erases some of the graphics
			// Also, this allows for the previous layer's graphics to now be at the top and fully visible
	}
	
	public void deleteLayer() {	// User deletes the current layer
		if ((cLayerNum != imageArray.size() - 1) || (cLayerNum > 0)) {	// If the current layer is not the only layer left
			BufferedImage bImage = new BufferedImage(paintLab.getAppWidth(), paintLab.getCanvasHeight(), BufferedImage.TYPE_INT_ARGB);
			Graphics2D buffg = (Graphics2D) bImage.getGraphics();
			buffg.fillRect(0, 0, paintLab.getAppWidth(), paintLab.getCanvasHeight());	// Creates a blank image the size of the canvas
			
			imageArray.set(cLayerNum, bImage);	// Sets the current layer to this blank image
			deleteLayer = true;
			changeLayer = true;
			paintLab.repaint();	// The blank image (user-requested deleted layer) clears the canvas and the other layers are redrawn on top
		}
		else {		// User cannot delete the only layer
			JOptionPane.showMessageDialog(null, "Sorry, but you cannot delete your only layer.");
			paintLab.repaint();
		}
	}
	
	public ArrayList<BufferedImage> getImageArray() {	// Returns the private imageArray
		return imageArray;
	}
	
	public int getcLayerNum() {	// Returns the private cLayerNum attribute, the current index of imageArray, so that other classes can properly access cLayerNum
		return cLayerNum;
	}
	
	public void setcLayerNum(int cNum) {	// Sets the cLayerNum to the new current layer's index
		cLayerNum = cNum;
	}
}