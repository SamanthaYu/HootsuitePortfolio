/*****************************************************************************
*   Lab13: The Paint Program
*   Name: Samantha Yu
*   Submitted: January 27, 2015
*   Teacher: Christopher Slowley
******************************************************************************/

import java.util.ArrayList;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.Rectangle;
import javax.swing.JOptionPane;
import java.awt.Frame;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class PaintApp extends Frame implements WindowListener, MouseListener, MouseMotionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5650761267721782655L;
	
	// Used when creating the frame of the paint program
	private int appletWidth, appletHeight, canvasHeight;
	private Menu menuBar;
	private Tools toolbar;
	
	private Rectangle canvasRect;	// Canvas is not visible and does not include menu bar
	
	private boolean firstPaint, menuChange, deleteLayer, changeLayer, continuePaint;	// Used as "switches" during program execution
	private int oldX, oldY, newX, newY;		// Used on mouse events
	
	// I decided to use the BufferedImage class instead of its superclass, the Image class, due to its ability to include transparency
	private ArrayList<BufferedImage> imageArray;	// Stores buffered images of each layer
	private int cLayerNum;	// The index, cLayerNum, of imageArray allows access to the current layer and makes a graphical context for that layer
	private Graphics2D g2Frame; 	// g2Frame paints that buffered image stored in imageArray at cLayerNum
	
	public static void main(String args[]) {	// The main method handles the application framework
		PaintApp paintProgram = new PaintApp();
		paintProgram.addWindowListener(paintProgram);
		paintProgram.addMouseListener(paintProgram);
		paintProgram.addMouseMotionListener(paintProgram);
		
		paintProgram.appletWidth = 761;
		paintProgram.appletHeight = 380;
		paintProgram.setSize(paintProgram.appletWidth, paintProgram.appletHeight);
		
		paintProgram.setVisible(true);
		paintProgram.createApp();
	}
	
	public void createApp() {	// Applet, menu bar, canvas, and toolbar are created
		// The menu bar's selection boxes are created but not the buttons that you can see; i.e. buttons are invisible
		menuBar = new Menu(this);	// The menu bar must be constructed before the canvas
		createCanvas();
		toolbar = new Tools(this, menuBar);
		firstPaint = true;
	}
	
	public void paint(Graphics g) {		// Called after paintProgram became visible and whenever the graphical output needs to be updated or repainted
		g2Frame = (Graphics2D) g;		// The abstract Graphics2D class extends the abstract Graphics class

		if (firstPaint) {	
			menuBar.createMenu();		// Menu items are drawn onto the menu off-screen image
			g2Frame.drawImage(menuBar.menuImage, 0, 0, this);	// Off-screen image is drawn onto the applet; menu becomes visible
			createLayers();
			firstPaint = false;
			continuePaint = true;
		}
		else {
			if (continuePaint) {	// If a user's mouse did not click inside the menu, the mouse paints with the user's selected tool, size, color
				toolbar.useTool(menuBar.getNumTool(), oldX, oldY, newX, newY);
			}
			else {	// If a menu item is selected, then the area underneath the menu is not painted
				continuePaint = true;	// When the user selects a large size for their tool, then the canvas will not be accidentally painted.
			}
			
			paintLayers(g2Frame);
			
			if (menuChange) {	// If the user has selected a menu item, the menu bar is updated and redrawn
				menuBar.changeToolMenu();
				menuChange = false;
			}
			
			g2Frame.drawImage(menuBar.menuImage, 0, 0, this); // Prevents the menu bar from disappearing when the applet has gone inactive or been resized
		}
	}
	
	public void windowClosing(WindowEvent e) {
	    dispose();
	    System.exit(0);// normal exit of program
	}
	
	// Since these mouse events are required to be implemented, because this class implements the WindowListener
	// However, this paint program does not need these mouse events so these methods are left blank
	public void windowOpened(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowActivated(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}
	
	private void createCanvas() {	// Creates the canvas that the user can draw on; user cannot draw on menu
		canvasHeight = appletHeight - menuBar.getMenuHeight();
		canvasRect = new Rectangle(0,menuBar.getMenuHeight(),appletWidth, canvasHeight);
	}
	
	private void createLayers() {	// Creates an ArrayList of BufferedImages to contain the layers and creates an initial layer
		imageArray = new ArrayList<BufferedImage>();
		
		BufferedImage bImage = new BufferedImage(getAppletWidth(), getCanvasHeight(), BufferedImage.TYPE_INT_ARGB);
		imageArray.add(bImage);		// Adds the first layer
		cLayerNum = 0;
		repaint();
	}
	
	public void newLayer() {		// Creates a new layer after the current layer
		BufferedImage bImage = new BufferedImage(getAppletWidth(), getCanvasHeight(), BufferedImage.TYPE_INT_ARGB);
		cLayerNum++;
		imageArray.add(cLayerNum,bImage);	// Adds that layer after the current layer
		changeLayer = true;
		repaint();
	}
	
	public void previousLayer() {	// User switches to the previous layer
		if (cLayerNum > 0) {		// If the previous layer's index exists in imageArray
			cLayerNum--;
			changeLayer = true;
		}
		else {	// Prevents the user from accessing a layer that does not exist and getting an index out of bounds error
			JOptionPane.showMessageDialog(null, "Sorry, but you cannot go to a layer that does not exist yet.");
		}
		repaint();	// The graphical output is repainted, because when the notification pops up it erases some of the graphics
			// Also, this allows for the previous layer's graphics to now be at the top and fully visible
	}
	
	public void nextLayer() {	// User switches to the next layer
		if (cLayerNum < imageArray.size() - 1) {	// If the next layer's index exists in imageArray
			cLayerNum++;
			changeLayer = true;
		}
		else {
			JOptionPane.showMessageDialog(null, "Sorry, but you cannot go to a layer that does not exist yet.");
		}
		repaint();	// The graphical output is repainted, because when the notification pops up it erases some of the graphics
			// Also, this allows for the previous layer's graphics to now be at the top and fully visible
	}
	
	public void deleteLayer() {	// User deletes the current layer
		if ((cLayerNum != imageArray.size() - 1) || (cLayerNum > 0)) {	// If the current layer is not the only layer left
			BufferedImage bImage = new BufferedImage(getAppletWidth(), getCanvasHeight(), BufferedImage.TYPE_INT_ARGB);
			Graphics2D buffg = (Graphics2D) bImage.getGraphics();
			buffg.fillRect(0, 0, getAppletWidth(), getCanvasHeight());	// Creates a blank image the size of the canvas
			
			imageArray.set(cLayerNum, bImage);	// Sets the current layer to this blank image
			deleteLayer = true;
			changeLayer = true;
			repaint();	// The blank image (user-requested deleted layer) clears the canvas and the other layers are redrawn on top
		}
		else {		// User cannot delete the only layer
			JOptionPane.showMessageDialog(null, "Sorry, but you cannot delete your only layer.");
			repaint();
		}
	}
	
	private void paintLayers(Graphics2D g2Frame) {	// When a layer is created or deleted, or the user decides to switch to a different layer
		if (deleteLayer) {	// A layer is deleted (can be any layer, not just the last layer in imageArray)
			g2Frame.drawImage(imageArray.get(cLayerNum), 0, menuBar.getMenuHeight(), this);		// Draws the blank deleted layer
				// Otherwise, the deleted layer will remain and is not erased on screen
			
			for (int k = 0; k < imageArray.size(); k++) {	// Then draws the rest of the layers in ascending order
				if (k!=cLayerNum) {
					g2Frame.drawImage(imageArray.get(k), 0, menuBar.getMenuHeight(), this);
				}
			}
			
			deleteLayer = false;
			imageArray.remove(cLayerNum);		// Removes the blank deleted layer from imageArray
			
			if (cLayerNum == imageArray.size())	// If the deleted layer was the last layer, then decrease cLayerNum
				cLayerNum--;					// If not, then cLayerNum is not decreased
				// eg If the third layer is deleted, then the next layer which used to be the fourth layer is now the third layer
			
			g2Frame.drawImage(imageArray.get(cLayerNum), 0, menuBar.getMenuHeight(), this);	// The current layer is drawn last for visibility
		}
		else {	// If you are not deleting a layer, update only the current layer's graphics.
				// If you constantly redraw the other layers, then you would get flickering
			g2Frame.drawImage(imageArray.get(cLayerNum), 0, menuBar.getMenuHeight(), this);
		}
		
		if (changeLayer) {	// If a layer is created or deleted, or the user switches to the previous or next layer
			menuBar.changeLayerMenu();	// Layer status is updated
			changeLayer = false;
		}
	}
	
	public int getcLayerNum() {		// Returns the private cLayerNum attribute, the current index of imageArray, so that other classes can properly access cLayerNum
		return cLayerNum;
	}
	
	public int getAppletWidth() {	// Returns the private appletWidth attribute
		return appletWidth;
	}
	
	public int getCanvasHeight() {	// Returns the private canvasHeight attribute
		return canvasHeight;
	}
	
	public ArrayList<BufferedImage> getImageArray() {	// Returns the private imageArray
		return imageArray;
	}
	
	// Since these mouse events are required to be implemented, because this class implements the MouseListener and MouseMotionListener
	// However, this paint program does not need these mouse events so these methods are left blank
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseMoved(MouseEvent e) {}	/* When the mouse is moving but none of the buttons are held down */
	
	public void mousePressed(MouseEvent e) {	// When any of the mouse buttons are pressed down
		menuBar.select(e.getX(), e.getY());
		newX = e.getX();
		newY = e.getY();
		oldX = e.getX();  
		oldY = e.getY();
		
		if (menuBar.menuRect.contains(e.getX(),e.getY())) {
			continuePaint = false;	// After the user selects a menu item, continuePaint will prevent the area under the menu from getting painted.
			menuChange = true;
			repaint();
		}
		
		if (canvasRect.contains(e.getX(), e.getY())) {	// The applet repaints if the user clicks inside the canvas
			repaint();
		}
	}
	
	public void mouseDragged(MouseEvent e) {	// When any of the mouse buttons are held down while the mouse is dragged
		oldX = newX;
		oldY = newY;
	   	newX = e.getX();
	   	newY = e.getY();

		if (canvasRect.contains(e.getX(), e.getY())) {	// The applet repaints only if the user drags the mouse inside the canvas
			repaint();
		}
	}
	
	public void mouseReleased(MouseEvent e) {		// When any of the mouse buttons are lifted up
		newX = e.getX();
		newY = e.getY();

		if (canvasRect.contains(e.getX(), e.getY())) {	// The applet repaints only if the user lifts the mouse inside the canvas
			repaint();
		}
	}

	public void update(Graphics g) {
		// When repaint() is called, the update() then calls paint()
		// Since "default implementation of update() clears the Component's background before calling paint()", 
		// (see http://journals.ecs.soton.ac.uk/java/tutorial/ui/drawing/update.html)
		// Then I removed the background layers from flickering by drawing the layers here
		for (int k = 0; k < imageArray.size(); k++) {
			g2Frame.drawImage(imageArray.get(k), 0, menuBar.getMenuHeight(), this);
		}
		paint(g);
	}
}