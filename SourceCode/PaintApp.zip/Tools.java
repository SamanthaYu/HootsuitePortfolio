/*****************************************************************************
*   Lab13: The Paint Program: Tools class
*   Name: Samantha Yu
*   Submitted: January 27, 2015
*   Teacher: Christopher Slowley
******************************************************************************/

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Random;

public class Tools {
	BufferedImage cvMem;	// "Current virtual memory"; off-screen image the current layer which is painted upon
	
	// The Graphics2D class provides "more sophisticated control over geometry, coordinate transformations, color management, and text layout"
	// (see "http://docs.oracle.com/javase/7/docs/api/java/awt/Graphics2D.html") than its superclass, the Graphics class,
	// Such as being able to paint lines that have different edges
	Graphics2D cgBuffer;	// "Current graphics' buffer"; a graphics context for drawing an off-screen image; all cgBuffer information is sent to cvMem
	
	PaintApp paintLab;	// A PaintApp object has only one instance and allows this class to access its non-static methods and attributes
		// I did not make PaintApp's attributes static, because those attributes refer to the one and same object, the paint program
		// I did not want to place the Tools' methods into PaintApp, because those methods belong in its own separate category
		// So, this Tools class must be able to access and change the graphical output of PaintApp such as imageArray
	Menu menuBar;
	private int randX, randY;
	
	public Tools(PaintApp pLab, Menu menuB) {		// A Tools object is constructed
		menuBar = menuB;	// Initializes menuBar to the actual menu and paintLab to the actual PaintApp
		paintLab = pLab;	// So that Tools class' methods can access the non-static fields and methods, such as imageArray 
	}
	
	private void pencil(int oldX, int oldY, int newX, int newY) {	// Pencil tool with a rounded stroke
		cgBuffer.setStroke(new BasicStroke(menuBar.getStrokeSize(), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
		cgBuffer.drawLine(oldX,oldY,newX,newY);
	}
	
	private void brush(int oldX, int oldY, int newX, int newY) {	// Brush tool (has "missing" lines in its stroke at a curve)
		cgBuffer.setStroke(new BasicStroke(menuBar.getStrokeSize(), BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER)); 
		cgBuffer.drawLine(oldX,oldY,newX,newY);
	}
	
	private void spray(int newX, int newY) {	// Spray can tool
		Random rand = new Random();
		
		for (int k=1; k<2*menuBar.getStrokeSize(); k++) {	// Several tiny random circles are painted around the current coordinate
			randX = rand.nextInt(menuBar.getStrokeSize()) + newX - (int) menuBar.getStrokeSize()/2;
			randY = rand.nextInt(menuBar.getStrokeSize()) + newY - (int) menuBar.getStrokeSize()/2;
			cgBuffer.fillOval(randX, randY, (int) 3, (int) 3);	
		}
	}
	
	public void useTool(int numTool, int oldX, int oldY, int newX, int newY) {	// Selects specific tool
		cvMem = paintLab.getImageArray().get(paintLab.getcLayerNum());	// Grabs the current layer
		cgBuffer = (Graphics2D) cvMem.getGraphics();	// Creates the graphics context for that layer to be used in double buffering
		cgBuffer.setColor(menuBar.paintColor);
		
		// The y-coordinates are subtracted by the menu bar's height, because the canvas layers do not include the menu bar
		if (numTool == 1)
			pencil(oldX, oldY - menuBar.getMenuHeight(), newX, newY - menuBar.getMenuHeight());
		else if (numTool == 2)
			brush(oldX, oldY - menuBar.getMenuHeight(), newX, newY - menuBar.getMenuHeight());
		else if (numTool == 3)
			spray(newX, newY - menuBar.getMenuHeight());
	}
}